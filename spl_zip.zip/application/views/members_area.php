<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

	$cricketMatchesTxt = file_get_contents('http://cricapi.com/api/matches?apikey=0dakSmnWhmWY3ACSaTdHN3kggjD3');	// change with your API key
	$cricketMatches = json_decode($cricketMatchesTxt);

    foreach($cricketMatches->matches as $item) {
?>
	<?php 
     $id = $item->unique_id;
	$cricketScoreTxt = file_get_contents('http://cricapi.com/api/cricketScore?uniq_id=$id&apikey=0dakSmnWhmWY3ACSaTdHN3kggjD3') ?>
	?>
	<h4> <?php echo ($cricketScoreTxt->score); ?> </h4>
<?php } ?>
</body>
</html>